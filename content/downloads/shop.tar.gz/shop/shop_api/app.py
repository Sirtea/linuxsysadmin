from bottle import Bottle, response
from pymongo import MongoClient
import json
import os

app = Bottle()
db = MongoClient(host='mongodb://mongo1:27017,mongo2:27017,backoffice:27017', connect=False).shop
hostname = os.uname()[1]

@app.get('/products/')
def product_list():
    response.content_type = 'application/json'
    response.set_header('Backend', hostname)
    response.status = 200
    cursor = db.products.find()
    data = [doc for doc in cursor]
    return json.dumps(data, indent=4) + '\n'

@app.get('/products/<id>')
def product_detail(id):
    response.content_type = 'application/json'
    response.set_header('Backend', hostname)
    response.status = 200
    product = db.products.find_one({'_id': id})
    if product is None:
        response.status = 404
        error = {'error': 'Product %s not found' % id}
        return json.dumps(error, indent=4) + '\n'
    return json.dumps(product, indent=4) + '\n'
