from bottle import Bottle, view, request, redirect
from pymongo import MongoClient

app = Bottle()
db = MongoClient(host='mongodb://mongo1:27017,mongo2:27017,backoffice:27017', connect=False).shop

@app.get('/')
@view('index')
def index():
    return {}

@app.get('/products')
@view('product_list')
def product_list():
    cursor = db.products.find()
    products = [doc for doc in cursor]
    return {
        'products': products,
    }

@app.get('/products/add')
@view('product_form')
def product_add():
    return {}

@app.post('/products/add')
def do_product_add():
    product = {
        '_id': request.forms.get('sku'),
        'description': request.forms.get('description'),
        'price': float(request.forms.get('price')),
    }
    db.products.insert_one(product)
    redirect('/products')

@app.get('/products/delete/<id>')
def do_product_delete(id):
    db.products.delete_one({'_id': id})
    redirect('/products')
