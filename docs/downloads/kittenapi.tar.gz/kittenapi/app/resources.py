import falcon
from models import KittenDAO, Kitten


class KittenCollectionResource:
    def __init__(self):
        self.kittens = KittenDAO()

    def on_get(self, req, resp):
        resp.media = [{'id': k.id, 'name': k.name} for k in self.kittens.get()]

    def on_post(self, req, resp):
        name = req.media.get('name')
        if name is not None:
            k = Kitten(name)
            self.kittens.save(k)
            resp.status = falcon.HTTP_201
            resp.media = {'id': k.id, 'name': k.name}
        else:
            resp.status = falcon.HTTP_400
            resp.media = {'error': 'Property \'name\' is required'}


class KittenResource:
    def __init__(self):
        self.kittens = KittenDAO()

    def on_get(self, req, resp, id):
        k = self.kittens.get(id)
        if k is not None:
            resp.media = {'id': k.id, 'name': k.name}
        else:
            resp.status = falcon.HTTP_404

    def on_put(self, req, resp, id):
        name = req.media.get('name')
        if name is not None:
            k = self.kittens.get(id)
            if k is not None:
                k.name = name
                self.kittens.save(k)
                resp.media = {'id': k.id, 'name': k.name}
            else:
                resp.status = falcon.HTTP_404
        else:
            resp.status = falcon.HTTP_400
            resp.media = {'error': 'Property \'name\' is required'}

    def on_delete(self, req, resp, id):
        k = self.kittens.get(id)
        if k is not None:
            self.kittens.delete(k)
        else:
            resp.status = falcon.HTTP_404
