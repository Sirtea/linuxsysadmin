import os
import pymongo

MONGODB_URI = os.environ.get('MONGODB_URI')


class Kitten:
    def __init__(self, name, id=None):
        self.name = name
        self.id = id


class KittenDAO:
    def __init__(self):
        self.db = pymongo.MongoClient(host=MONGODB_URI).get_database()

    def get(self, id=None):
        if id is None:
            cursor = self.db.kittens.find()
            return [Kitten(doc['name'], doc['_id']) for doc in cursor]
        else:
            doc = self.db.kittens.find_one({'_id': id})
            return Kitten(doc['name'], doc['_id']) if doc is not None else None

    def save(self, kitten):
        if kitten.id is None:
            doc = self.db.counters.find_one_and_update(
                {'_id': 'kittens'}, {'$inc': {'sequence': 1}}, upsert=True,
                return_document=pymongo.collection.ReturnDocument.AFTER)
            kitten.id = doc['sequence']
            doc = {'_id': kitten.id, 'name': kitten.name}
            self.db.kittens.insert_one(doc)
        else:
            doc = {'_id': kitten.id, 'name': kitten.name}
            self.db.kittens.replace_one({'_id': kitten.id}, doc)

    def delete(self, kitten):
        if kitten.id is not None:
            self.db.kittens.delete_one({'_id': kitten.id})
            kitten.id = None
