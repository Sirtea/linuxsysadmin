import falcon
from resources import KittenCollectionResource, KittenResource

app = falcon.API()
app.add_route('/kittens', KittenCollectionResource())
app.add_route('/kittens/{id:int}', KittenResource())
